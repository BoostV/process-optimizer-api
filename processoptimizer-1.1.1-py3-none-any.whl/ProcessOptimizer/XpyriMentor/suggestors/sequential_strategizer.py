from __future__ import annotations

import math
import warnings
from typing import Any, Callable, Collection, Iterable

import numpy as np
from ProcessOptimizer.space import Space

from .default_suggestor import DefaultSuggestor
from .lhs_suggestor import LHSSuggestor
from .po_suggestor import OptimizerSuggestor
from .suggestor import IncompatibleNumberAsked, Suggestor


class SequentialStrategizer:
    """
    Stratgizer that uses a sequence of suggestors, each with a budget of suggestions to
    make.

    It uses the suggestors in order, skipping suggestors with a budget of suggestions
    that have already been made.

    When creating from a definition dictionary, the dictionary should have the key
    `"suggestors"`, and the corresponding value should be a list of dictionaries
    (child suggestor dictionaries), each representing a suggestor and its configuration.
    Each child suggestor dictionary should have the key `suggestor_budget` (the number of
    suggestions the suggestor can make) and the key `suggestor_name` (the name of the
    suggestor).

    Example of a valid definition, using different approaches:
    definition = {
        "suggestor_name": "Sequential",
        "suggestors": [
            {
                "suggestor_budget": 5,
                "suggestor": {"suggestor_name": "LHS"},
            },
            {
                "suggestor_budget": 20,
                "suggestor": {"suggestor_name": "PO", "n_initial_points": 0},
            },
            {
                "suggestor_budget": 10,
                "suggestor": ConstantSuggestor(space, [42]),
            },
        ]
    }
    """

    def __init__(self, suggestors: list[tuple[int, Suggestor]], **kwargs):
        """
        Initialize the strategizer with a list of suggestors and their budgets.

        Parameters
        ----------
        * suggestors [`list[tuple[int, Suggestor]]`]:
            A list of tuples where the first element is the number of suggestions the
            suggestor can make (its budget) and the second element is the suggestor. A
            negative number of suggestions is interpreted as infinity, and can only be
            used as budget for the last suggestor.

            If the first suggestor is a DefaultSuggestor, it will be replaced with a
            LHSSuggestor with the same budget. If any other suggestor is a
            DefaultSuggestor, it will be replaced with a POSuggestor.
        """
        for n, (budget, suggestor) in enumerate(suggestors):
            if isinstance(suggestor, DefaultSuggestor):
                if n == 0:
                    suggestors[n] = (
                        budget,
                        LHSSuggestor(
                            space=suggestor.space, rng=suggestor.rng, n_points=budget
                        ),
                    )
                else:
                    suggestors[n] = (
                        budget,
                        OptimizerSuggestor(
                            space=suggestor.space,
                            rng=suggestor.rng,
                            n_objectives=suggestor.n_objectives,
                        ),
                    )
            if budget < 0:
                # Interpret negative budgets as infinity
                suggestors[n] = (float("inf"), suggestors[n][1])
            if hasattr(suggestors[n][1], "n_points"):
                if suggestors[n][1].n_points != suggestors[n][0]:
                    warnings.warn(
                        f"Budget of {suggestors[n][0]} points does not match number of "
                        "points for suggestor of type "
                        f"{suggestors[n][1].__class__.__name__}."
                    )
            if math.isinf(suggestors[n][0]):
                if n < len(suggestors) - 1:
                    raise ValueError(
                        "Only the last suggestor can have an infinite budget."
                    )
        self.suggestors = suggestors

    def suggest(
        self, Xi: Collection[Iterable], Yi: Iterable, n_points_to_suggest: int = 1
    ):
        # We will skip as many points as we have already been told about.
        number_left_to_skip = len(Xi)  # Running tally of points to skip.
        number_left_to_find = n_points_to_suggest  # Running tally of points to find.
        # Both of these will be decremented as we go through the suggestors.
        suggestions = []
        for budget, suggestor in self.suggestors:
            if number_left_to_skip >= budget:
                # If we have been told enough points, we have to skip this suggestor.
                number_left_to_skip -= budget
                continue
            elif number_left_to_skip + number_left_to_find >= budget:
                # If we need more points than the suggestor can give us, we take all the
                # points the suggestor can give us and continue with the next suggestor.
                number_from_this_suggestor = budget - number_left_to_skip
                number_left_to_skip = 0
            else:
                # If we need fewer points than the suggestor can give us, we take the
                # points we need and stop.
                number_from_this_suggestor = number_left_to_find
            suggestions.extend(suggestor.suggest(Xi, Yi, number_from_this_suggestor))
            number_left_to_find -= number_from_this_suggestor
            if number_left_to_find == 0:
                # If we have already found all the points we need, we can stop.
                break
        if len(suggestions) < n_points_to_suggest:
            raise IncompatibleNumberAsked("Not enough suggestions")
        return np.array(suggestions, dtype=object)

    def __str__(self):
        return "Sequential Strategizer with suggestors: " + ", ".join(
            suggestor.__class__.__name__ for _, suggestor in self.suggestors
        )

    def __repr__(self):
        suggestor_list_str = ", ".join(
            f"({budget}, {suggestor.__class__.__name__}(...))"
            for budget, suggestor in self.suggestors
        )
        return f"SequentialStrategizer(suggestors=[{suggestor_list_str}]"

    @classmethod
    def create_from_definition(
        cls,
        space: Space,
        suggestor_factory: Callable[..., Suggestor],
        definition: dict[str, Any],
        n_objectives: int,
        rng: np.random.Generator,
    ) -> SequentialStrategizer:
        suggestors = []
        # To make the child suggestors independent, we spawn a random number generator
        # for each. This allows them to be fully deterministic based on the original
        # seed, while what they suggest is not affected by how many times the other
        # sibling suggestors have been used. If this was not here, for two child
        # suggestors `A` and `B`, `[A.suggest(), B.suggest(), A.suggest()]` would risk
        # yielding different points than `[A.suggest(), A.suggest(), B.suggest()]`.
        # This probably wouldn't cause an issue in production, but it would be annoying
        # when debugging.
        child_rngs = rng.spawn(len(definition["suggestors"]))
        for suggestor in definition["suggestors"]:
            suggestor = suggestor.copy()  # Preserving the input dict
            n = suggestor.pop("suggestor_budget")
            if "suggestor" in suggestor:
                if len(suggestor) > 1:
                    raise ValueError(
                        "If a suggestor definition for a SequentialStrategizer has a "
                        "'suggestor' key, it should only have that key and "
                        "'suggestor_budget', but it has the keys `suggestor_budget`, "
                        f"{', '.join(suggestor.keys())}."
                    )
                suggestor = suggestor["suggestor"]
            if isinstance(suggestor, dict) and "n_points" not in suggestor:
                # If the suggestor is to be created (is a dict), it might need to know
                # how many points it has available.
                suggestor["n_points"] = n
            suggestors.append(
                (
                    n,
                    suggestor_factory(space, suggestor, n_objectives, child_rngs.pop()),
                )
            )
        return cls(suggestors=suggestors)
